		public class DSA23Q1
		{
			// function to return max
			// of left subtree height
			// or right subtree height
			static int findDepthRec(String tree,
									int n, int index)
			{
				if (index >= n ||
					tree.charAt(index) == 'l')
					return 0;
		
				// calculate height of left subtree
				// (In pre-order left subtree
				// is processed before right)
				index++;
				int left = findDepthRec(tree,
										n, index);
		
				// calculate height of
				// right subtree
				index++;
				int right = findDepthRec(tree, n, index);
		
				return Math.max(left, right) + 1;
			}
		
			// Wrapper over findDepthRec()
			static int findDepth(String tree,
								int n)
			{
				int index = 0;
				return (findDepthRec(tree,
									n, index));
			}
		

			public static void main(String[] args)
			{
				String tree = "nlnll";
				int n = tree.length();
				System.out.println(findDepth(tree, n));
			}
		}
		
		
